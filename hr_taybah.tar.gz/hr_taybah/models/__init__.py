# -*- coding: utf-8 -*-

from . import models
from . import  xlrd
from odoo.tools import  convert