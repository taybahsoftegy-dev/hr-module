# -*- coding: utf-8 -*-
from odoo import http

# class HrTaybah(http.Controller):
#     @http.route('/hr_taybah/hr_taybah/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/hr_taybah/hr_taybah/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('hr_taybah.listing', {
#             'root': '/hr_taybah/hr_taybah',
#             'objects': http.request.env['hr_taybah.hr_taybah'].search([]),
#         })

#     @http.route('/hr_taybah/hr_taybah/objects/<model("hr_taybah.hr_taybah"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('hr_taybah.object', {
#             'object': obj
#         })